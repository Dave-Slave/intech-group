<?php
/**
 * @version		$Id: feed.php 3758 2014-10-02 10:29:50Z mic $
 * @package		Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']		= 'RSS / Feeds';

// Text
$_['text_success']		= 'Feed erfolgreich aktualisiert';
$_['text_list']			= 'Übersicht';

// Column
$_['column_name']		= 'Name';
$_['column_status']		= 'Status';
$_['column_action']		= 'Aktion';

// Error
$_['error_permission']	= 'Keine Rechte für diese Aktion';